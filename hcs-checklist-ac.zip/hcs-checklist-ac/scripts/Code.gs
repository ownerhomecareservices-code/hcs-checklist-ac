// ═══════════════════════════════════════════════════════════════
// HOME CARE SERVICES — Checklist AC Integration v2
// Google Apps Script — Web App
// Support: Cleaning, Service/Repair, Instalasi
//
// CARA UPDATE (jika sudah pernah deploy sebelumnya):
// 1. Buka script.google.com → pilih project yang sudah ada
// 2. Hapus semua kode lama → paste kode ini
// 3. Klik Save (Ctrl+S)
// 4. Klik Deploy → Manage Deployments → Edit (ikon pensil)
// 5. Version → "New version" → Deploy
// 6. URL TIDAK BERUBAH — tidak perlu update di aplikasi
//
// CARA SETUP BARU (belum pernah deploy):
// 1. Buka script.google.com → New Project
// 2. Paste seluruh kode ini
// 3. Ganti SPREADSHEET_ID di bawah
// 4. Deploy → New Deployment → Web App
//    - Execute as: Me
//    - Who has access: Anyone
// ═══════════════════════════════════════════════════════════════

const SPREADSHEET_ID = '1j28TXOAeI4q712joER2eg1gPDv1yfcaBxa3oNcq2f_c';

// Sheet names
const SH_CLEANING   = 'Cleaning';
const SH_SERVICE    = 'Service';
const SH_INSTALASI  = 'Instalasi';
const SH_PARAMETER  = 'Parameter';
const SH_DASHBOARD  = 'Dashboard';

// ───────────────────────────────────────────────────────────────
// MAIN HANDLER
// ───────────────────────────────────────────────────────────────
function doPost(e) {
  try {
    const raw  = e.postData.contents;
    const data = JSON.parse(raw);
    const ss   = SpreadsheetApp.openById(SPREADSHEET_ID);

    // Route by job type
    const jobType = data.jobType || data.type || 'unknown';

    if (jobType === 'cleaning') {
      writeCleaning(ss, data);
    } else if (jobType === 'service') {
      writeService(ss, data);
    } else if (jobType === 'instalasi') {
      writeInstalasi(ss, data);
    } else if (jobType === 'test') {
      writeTest(ss, data);
    }

    // Always write parameter detail
    if (jobType !== 'test') {
      writeParameter(ss, data);
    }

    // Update dashboard
    updateDashboard(ss);

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'OK', id: data.id, jobType }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'ERROR', message: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ───────────────────────────────────────────────────────────────
// CLEANING SHEET
// ───────────────────────────────────────────────────────────────
function writeCleaning(ss, d) {
  let sh = ss.getSheetByName(SH_CLEANING);
  if (!sh) { sh = ss.insertSheet(SH_CLEANING); initCleaningHeader(sh); }

  const tgl = d.tgl ? new Date(d.tgl).toLocaleDateString('id-ID') : '-';
  const ts  = new Date(d.ts).toLocaleString('id-ID');
  const pct = d.ckT ? Math.round((d.ckD / d.ckT) * 100) + '%' : '-';

  sh.appendRow([
    d.id, ts, tgl, d.jam || '-', d.status || 'selesai',
    d.acType, d.acLabel,
    d.tek, d.pel, d.lok, d.hp || '-',
    d.mrk, d.pk, d.freon || '-', d.sn || '-',
    d.ckD, d.ckT, pct,
    d.okB, d.noB, d.okA, d.noA,
  ]);

  formatRow(sh, sh.getLastRow(), d.status, d.noA);
}

function initCleaningHeader(sh) {
  const h = [
    'ID', 'Timestamp', 'Tanggal', 'Jam', 'Status',
    'Tipe AC (kode)', 'Tipe AC', 'Teknisi',
    'Customer', 'Lokasi', 'No. HP',
    'Brand', 'PK', 'Freon', 'Model/SN',
    'Langkah selesai', 'Total langkah', 'Progress',
    'Before sesuai', 'Before tdk sesuai',
    'After sesuai', 'After tdk sesuai',
  ];
  styleHeader(sh, h, '#0C447C');
}

// ───────────────────────────────────────────────────────────────
// SERVICE SHEET
// ───────────────────────────────────────────────────────────────
function writeService(ss, d) {
  let sh = ss.getSheetByName(SH_SERVICE);
  if (!sh) { sh = ss.insertSheet(SH_SERVICE); initServiceHeader(sh); }

  const tgl = d.tgl ? new Date(d.tgl).toLocaleDateString('id-ID') : '-';
  const ts  = new Date(d.ts).toLocaleString('id-ID');
  const keluhanStr  = (d.keluhan  || []).join(', ') + (d.keluhanLain  ? ', ' + d.keluhanLain  : '');
  const tindakanStr = (d.tindakan || []).join(', ') + (d.tindakanLain ? ', ' + d.tindakanLain : '');
  const anaObj = d.analisa || {};

  sh.appendRow([
    d.id, ts, tgl, d.jam || '-', d.status || 'selesai',
    d.acType, d.acLabel,
    d.tek, d.pel, d.lok, d.hp || '-',
    d.mrk, d.pk, d.freon || '-', d.sn || '-',
    keluhanStr,
    tindakanStr,
    d.okB, d.noB, d.okA, d.noA,
    anaObj.penyebab    || '-',
    anaObj.komponen    || '-',
    anaObj.tindakan    || '-',
    anaObj.risiko      || '-',
    anaObj.rekomendasi || '-',
    anaObj.redflag     || '-',
  ]);

  formatRow(sh, sh.getLastRow(), d.status, d.noA);
}

function initServiceHeader(sh) {
  const h = [
    'ID', 'Timestamp', 'Tanggal', 'Jam', 'Status',
    'Tipe AC (kode)', 'Tipe AC', 'Teknisi',
    'Customer', 'Lokasi', 'No. HP',
    'Brand', 'PK', 'Freon', 'Model/SN',
    'Keluhan customer',
    'Tindakan dilakukan',
    'Before sesuai', 'Before tdk sesuai',
    'After sesuai', 'After tdk sesuai',
    'Penyebab utama', 'Komponen bermasalah',
    'Tindakan', 'Risiko', 'Rekomendasi', 'Red flag',
  ];
  styleHeader(sh, h, '#BA7517');
}

// ───────────────────────────────────────────────────────────────
// INSTALASI SHEET
// ───────────────────────────────────────────────────────────────
function writeInstalasi(ss, d) {
  let sh = ss.getSheetByName(SH_INSTALASI);
  if (!sh) { sh = ss.insertSheet(SH_INSTALASI); initInstalasiHeader(sh); }

  const tgl = d.tgl ? new Date(d.tgl).toLocaleDateString('id-ID') : '-';
  const ts  = new Date(d.ts).toLocaleString('id-ID');
  const anaObj = d.analisa || {};

  sh.appendRow([
    d.id, ts, tgl, d.jam || '-', d.status || 'selesai',
    d.acType, d.acLabel,
    d.tek, d.helper || '-', d.pel, d.lok, d.hp || '-',
    d.mrk, d.pk, d.freon || '-', d.sn || '-',
    d.jenisInst || 'Baru',
    d.okB, d.noB, d.okA, d.noA,
    anaObj.kendala    || '-',
    anaObj.tindakan   || '-',
    anaObj.risiko     || '-',
    anaObj.rekomendasi|| '-',
    anaObj.redflag    || '-',
  ]);

  formatRow(sh, sh.getLastRow(), d.status, d.noA);
}

function initInstalasiHeader(sh) {
  const h = [
    'ID', 'Timestamp', 'Tanggal', 'Jam', 'Status',
    'Tipe AC (kode)', 'Tipe AC', 'Teknisi', 'Helper',
    'Customer', 'Lokasi', 'No. HP',
    'Brand', 'PK', 'Freon', 'Model/SN',
    'Jenis instalasi',
    'Survey sesuai', 'Survey tdk sesuai',
    'Running test sesuai', 'Running test tdk sesuai',
    'Kendala instalasi', 'Tindakan',
    'Risiko', 'Rekomendasi maintenance', 'Red flag',
  ];
  styleHeader(sh, h, '#27500A');
}

// ───────────────────────────────────────────────────────────────
// PARAMETER DETAIL SHEET (semua jenis pekerjaan)
// ───────────────────────────────────────────────────────────────
function writeParameter(ss, d) {
  let sh = ss.getSheetByName(SH_PARAMETER);
  if (!sh) { sh = ss.insertSheet(SH_PARAMETER); initParameterHeader(sh); }

  const tgl = d.tgl ? new Date(d.tgl).toLocaleDateString('id-ID') : '-';
  const pVals = d.pVals || {};

  // Tulis semua seksi parameter
  Object.keys(pVals).forEach(sid => {
    const secData = pVals[sid];
    if (!secData || typeof secData !== 'object') return;

    Object.keys(secData).forEach(idx => {
      const p = secData[idx];
      if (!p) return;
      const status = p.ok === 1 ? 'Sesuai' : p.ok === 0 ? 'Tidak Sesuai' : '-';

      sh.appendRow([
        d.id, tgl, d.jobType || '-', d.acLabel || '-',
        d.tek, d.pel,
        sid, p.name || ('Parameter ' + idx),
        p.std || '-', p.val || '-', status
      ]);

      // Format status cell
      const lastRow = sh.getLastRow();
      const statusCol = 11;
      if (p.ok === 1) {
        sh.getRange(lastRow, statusCol).setBackground('#E1F5EE').setFontColor('#085041').setFontWeight('bold');
      } else if (p.ok === 0) {
        sh.getRange(lastRow, statusCol).setBackground('#FCEBEB').setFontColor('#791F1F').setFontWeight('bold');
      }
    });
  });
}

function initParameterHeader(sh) {
  const h = [
    'ID Checklist', 'Tanggal', 'Jenis Pekerjaan', 'Tipe AC',
    'Teknisi', 'Customer',
    'Seksi', 'Parameter', 'Standar', 'Nilai Aktual', 'Status'
  ];
  styleHeader(sh, h, '#444441');
}

// ───────────────────────────────────────────────────────────────
// TEST HANDLER
// ───────────────────────────────────────────────────────────────
function writeTest(ss, data) {
  // Pastikan semua sheet ada dengan header yang benar
  ensureSheet(ss, SH_CLEANING,  initCleaningHeader);
  ensureSheet(ss, SH_SERVICE,   initServiceHeader);
  ensureSheet(ss, SH_INSTALASI, initInstalasiHeader);
  ensureSheet(ss, SH_PARAMETER, initParameterHeader);
  ensureSheet(ss, SH_DASHBOARD, initDashboard);
  Logger.log('Test OK — semua sheet siap');
}

function ensureSheet(ss, name, initFn) {
  let sh = ss.getSheetByName(name);
  if (!sh) { sh = ss.insertSheet(name); initFn(sh); }
  return sh;
}

// ───────────────────────────────────────────────────────────────
// DASHBOARD
// ───────────────────────────────────────────────────────────────
function updateDashboard(ss) {
  let dash = ss.getSheetByName(SH_DASHBOARD);
  if (!dash) { dash = ss.insertSheet(SH_DASHBOARD); }
  refreshDashboard(dash, ss);
}

function initDashboard(dash) {
  dash.getRange('A1').setValue('HOME CARE SERVICES — Dashboard Checklist AC')
    .setFontSize(14).setFontWeight('bold').setFontColor('#0C447C');
}

function refreshDashboard(dash, ss) {
  const now = new Date().toLocaleString('id-ID');

  // Hitung dari masing-masing sheet
  function countRows(shName) {
    const sh = ss.getSheetByName(shName);
    return sh && sh.getLastRow() > 1 ? sh.getLastRow() - 1 : 0;
  }

  function countWithAlert(shName) {
    const sh = ss.getSheetByName(shName);
    if (!sh || sh.getLastRow() < 2) return 0;
    const data = sh.getDataRange().getValues();
    // Kolom "After tdk sesuai" — cari di header
    const header = data[0];
    const alertCol = header.findIndex(h => String(h).includes('tdk sesuai') && String(h).includes('After'));
    if (alertCol < 0) return 0;
    return data.slice(1).filter(r => r[alertCol] > 0).length;
  }

  const clCount  = countRows(SH_CLEANING);
  const svcCount = countRows(SH_SERVICE);
  const instCount = countRows(SH_INSTALASI);
  const total = clCount + svcCount + instCount;
  const alerts = countWithAlert(SH_CLEANING) + countWithAlert(SH_SERVICE);

  // Teknisi aktif (dari cleaning sheet)
  const teknisiSet = new Set();
  const clSh = ss.getSheetByName(SH_CLEANING);
  if (clSh && clSh.getLastRow() > 1) {
    clSh.getRange(2, 8, clSh.getLastRow() - 1, 1).getValues().forEach(r => teknisiSet.add(r[0]));
  }
  const svcSh = ss.getSheetByName(SH_SERVICE);
  if (svcSh && svcSh.getLastRow() > 1) {
    svcSh.getRange(2, 8, svcSh.getLastRow() - 1, 1).getValues().forEach(r => teknisiSet.add(r[0]));
  }

  // Tulis dashboard
  const rows = [
    ['', ''],
    ['RINGKASAN', ''],
    ['Total pekerjaan', total],
    ['Cleaning', clCount],
    ['Service / Repair', svcCount],
    ['Instalasi', instCount],
    ['Perlu perhatian (after tdk sesuai)', alerts],
    ['Teknisi aktif', teknisiSet.size],
    ['', ''],
    ['Terakhir diupdate', now],
  ];

  rows.forEach((row, i) => {
    dash.getRange(i + 1, 1).setValue(row[0]).setFontSize(10);
    dash.getRange(i + 1, 2).setValue(row[1]).setFontSize(10).setFontWeight('bold');
  });

  // Format header rows
  dash.getRange(1, 1).setFontSize(14).setFontWeight('bold').setFontColor('#0C447C');
  dash.getRange(3, 1).setFontWeight('bold').setFontColor('#444441');

  // Alert row merah jika ada masalah
  if (alerts > 0) {
    dash.getRange(8, 1, 1, 2).setBackground('#FCEBEB');
    dash.getRange(8, 2).setFontColor('#791F1F');
  }

  dash.setColumnWidth(1, 280);
  dash.setColumnWidth(2, 160);
}

// ───────────────────────────────────────────────────────────────
// HELPERS
// ───────────────────────────────────────────────────────────────
function styleHeader(sh, headers, bgColor) {
  sh.appendRow(headers);
  const range = sh.getRange(1, 1, 1, headers.length);
  range.setBackground(bgColor)
       .setFontColor('#FFFFFF')
       .setFontWeight('bold')
       .setFontSize(10);
  sh.setFrozenRows(1);
  // Auto-resize key columns
  sh.setColumnWidth(1, 180);  // ID
  sh.setColumnWidth(2, 140);  // Timestamp
  sh.setColumnWidth(9, 200);  // Customer/Lokasi
}

function formatRow(sh, row, status, noA) {
  const statusCol = 5;
  const bg = status === 'selesai' ? '#E1F5EE' : '#FAEEDA';
  sh.getRange(row, statusCol).setBackground(bg).setFontWeight('bold');

  // Highlight merah jika ada parameter after tidak sesuai
  if (noA > 0) {
    sh.getRange(row, 1, 1, sh.getLastColumn()).setBackground('#FFF8F0');
  }
}

// ───────────────────────────────────────────────────────────────
// TEST FUNCTION — jalankan ini untuk verifikasi
// ───────────────────────────────────────────────────────────────
function testConnection() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  Logger.log('Terhubung ke: ' + ss.getName());

  // Test data cleaning
  const testCleaning = {
    id: 'TEST-CL-' + Date.now(), jobType: 'cleaning',
    acType: 'split', acLabel: 'AC Split',
    pel: 'Test Customer', lok: 'Jl. Test', hp: '081234567890',
    mrk: 'Panasonic', pk: '1 PK', freon: 'R-32', sn: 'TEST-SN',
    tek: 'Test Teknisi', tgl: new Date().toISOString().split('T')[0], jam: '10:00',
    ckD: 10, ckT: 12, okB: 7, noB: 2, okA: 8, noA: 0,
    status: 'selesai', ts: Date.now(),
    pVals: { before: { 0: { name: 'Suhu ruang', std: '26-34°C', val: '30', ok: 1 } } }
  };

  // Test data service
  const testService = {
    id: 'TEST-SVC-' + Date.now(), jobType: 'service',
    acType: 'split', acLabel: 'AC Split',
    pel: 'Test Customer 2', lok: 'Jl. Test 2', hp: '081234567891',
    mrk: 'Daikin', pk: '1½ PK', freon: 'R-410A', sn: '',
    tek: 'Test Teknisi', tgl: new Date().toISOString().split('T')[0], jam: '13:00',
    okB: 5, noB: 3, okA: 8, noA: 0,
    keluhan: ['Tidak dingin', 'Bunyi'], keluhanLain: '',
    tindakan: ['Isi refrigerant', 'Ganti kapasitor'], tindakanLain: '',
    analisa: { penyebab: 'Freon bocor', komponen: 'Kapasitor', tindakan: 'Ganti kapasitor + isi freon' },
    status: 'selesai', ts: Date.now(), pVals: {}
  };

  // Test data instalasi
  const testInstalasi = {
    id: 'TEST-INST-' + Date.now(), jobType: 'instalasi',
    acType: 'split', acLabel: 'AC Split',
    pel: 'Test Customer 3', lok: 'Jl. Test 3', hp: '081234567892',
    mrk: 'Mitsubishi', pk: '1 PK', freon: 'R-32', sn: '',
    tek: 'Test Teknisi', helper: 'Test Helper',
    tgl: new Date().toISOString().split('T')[0], jam: '09:00',
    jenisInst: 'Baru',
    okB: 6, noB: 1, okA: 10, noA: 0,
    analisa: { kendala: 'Tidak ada', tindakan: 'Instalasi berjalan lancar' },
    status: 'selesai', ts: Date.now(), pVals: {}
  };

  writeCleaning(ss, testCleaning);
  writeService(ss, testService);
  writeInstalasi(ss, testInstalasi);
  writeParameter(ss, testCleaning);
  updateDashboard(ss);

  Logger.log('Test berhasil! Cek spreadsheet — 3 sheet baru: Cleaning, Service, Instalasi.');
}
