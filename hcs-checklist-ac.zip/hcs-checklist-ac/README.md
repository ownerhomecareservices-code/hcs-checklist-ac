# HCS Checklist AC
**Home Care Services — Aplikasi Checklist Teknisi AC**

Aplikasi checklist digital untuk teknisi AC Home Care Services. Mendukung 3 jenis pekerjaan dengan parameter QC lengkap dan integrasi Google Sheets.

---

## 🔗 Akses Aplikasi

**→ [Buka Aplikasi Checklist](https://[USERNAME].github.io/hcs-checklist-ac)**

> Ganti `[USERNAME]` dengan username GitHub kamu setelah setup selesai.

---

## ✨ Fitur

### 3 Jenis Pekerjaan
| Jenis | Deskripsi |
|---|---|
| 🧹 **Cleaning** | Cuci AC lengkap — checklist langkah + parameter before/after (8 seksi) |
| 🔧 **Service / Repair** | Diagnosis & perbaikan — keluhan, komponen elektrikal & refrigerasi, red flag |
| 🏗️ **Instalasi** | Pasang baru, bongkar pasang, relokasi — survey lokasi s/d running test |

### 6 Tipe AC
AC Split · AC Cassette · AC Standing · AC Portable · AC Ducted · AC Window

### Fitur Lainnya
- ✅ Parameter QC aktual sesuai standar teknis (nilai angka + sesuai/tidak sesuai)
- ⚠️ Red flag otomatis — kondisi yang wajib dilaporkan ke katek
- 📊 Integrasi Google Sheets — data masuk otomatis saat checklist selesai
- 💾 Offline-ready — data tersimpan lokal jika tidak ada koneksi
- 🔄 Kirim ulang — data lokal bisa dikirim ulang saat koneksi tersedia
- 📱 Mobile-first — dioptimalkan untuk HP teknisi di lapangan

---

## 🚀 Cara Setup (Pertama Kali)

### 1. Fork / Clone Repository
```bash
git clone https://github.com/[USERNAME]/hcs-checklist-ac.git
```

### 2. Aktifkan GitHub Pages
1. Buka repository di GitHub
2. **Settings → Pages**
3. Source: **Deploy from a branch**
4. Branch: **main** / folder: **/ (root)**
5. Klik **Save**
6. Tunggu 1-2 menit → URL aplikasi aktif

### 3. Setup Google Apps Script
1. Buka [script.google.com](https://script.google.com)
2. Buat project baru → nama: **HCS Checklist AC**
3. Copy-paste isi file `scripts/Code.gs`
4. Ganti `SPREADSHEET_ID` dengan ID Google Sheets kamu
5. Jalankan `testConnection` untuk verifikasi
6. **Deploy → New Deployment → Web App**
   - Execute as: **Me**
   - Who has access: **Anyone**
7. Copy URL yang muncul

### 4. Setup URL di Aplikasi
1. Buka aplikasi di browser
2. Ketuk ⚙️ di pojok kanan atas
3. Paste URL Apps Script
4. Klik **Test Koneksi** → **Simpan Pengaturan**

---

## 📁 Struktur File

```
hcs-checklist-ac/
├── index.html          # Aplikasi utama (standalone HTML)
├── scripts/
│   └── Code.gs         # Google Apps Script untuk integrasi Sheets
├── docs/
│   └── PANDUAN_SETUP.md # Panduan setup lengkap
└── README.md           # Dokumentasi ini
```

---

## 📊 Struktur Google Sheets

Setelah terhubung, data masuk ke 5 sheet otomatis:

| Sheet | Isi |
|---|---|
| **Cleaning** | Satu baris per pekerjaan cleaning |
| **Service** | Satu baris per pekerjaan service/repair |
| **Instalasi** | Satu baris per pekerjaan instalasi |
| **Parameter** | Detail semua nilai aktual parameter |
| **Dashboard** | Ringkasan & monitoring real-time |

---

## 🔄 Cara Update Aplikasi

```bash
# Edit file yang perlu diupdate
# Lalu:
git add .
git commit -m "Update: deskripsi perubahan"
git push origin main
```

GitHub Pages otomatis update dalam 1-2 menit.

---

## 📋 Parameter QC yang Dicakup

### Cleaning (8 seksi parameter)
Before · Airflow · Drain · Suction · Evaporator · Blower · Outdoor · After

### Service (5 seksi parameter)
Diagnosa Before · Komponen Elektrikal · Komponen Refrigerasi · Airflow & Blower · After Service

### Instalasi (6 seksi parameter)
Survey Lokasi · Pemasangan Indoor · Pemasangan Outdoor · Piping & Refrigerant · Elektrikal · Running Test

---

## 👥 Tim

**Home Care Services** — Memberikan Kenyamanan

---

*Dibuat untuk operasional internal Home Care Services. Tidak untuk disebarluaskan.*
