# PANDUAN SETUP LENGKAP
## HCS Checklist AC — Home Care Services

---

## LANGKAH 1 — Fork Repository ke Akun GitHub Kamu

1. Buka: `https://github.com/[USERNAME]/hcs-checklist-ac`
2. Klik tombol **Fork** di pojok kanan atas
3. Pilih akun GitHub kamu → klik **Create fork**

---

## LANGKAH 2 — Aktifkan GitHub Pages

1. Di repository hasil fork, klik **Settings**
2. Klik **Pages** di menu kiri
3. Di bagian **Source**: pilih **Deploy from a branch**
4. **Branch**: pilih `main` · **Folder**: pilih `/ (root)`
5. Klik **Save**
6. Tunggu 1–2 menit
7. URL aplikasi muncul di bagian atas halaman Pages:
   ```
   https://[USERNAME].github.io/hcs-checklist-ac
   ```
8. Bagikan URL ini ke semua teknisi — bookmark di HP masing-masing

---

## LANGKAH 3 — Setup Google Spreadsheet

1. Buka **sheets.google.com** → klik **+ Blank**
2. Beri nama: **HCS Checklist AC**
3. Copy **ID spreadsheet** dari URL:
   ```
   docs.google.com/spreadsheets/d/[COPY_BAGIAN_INI]/edit
   ```

---

## LANGKAH 4 — Setup Google Apps Script

1. Di spreadsheet, klik **Extensions → Apps Script**
2. Hapus semua kode yang ada
3. Copy-paste seluruh isi file `scripts/Code.gs` dari repository
4. Di baris ke-15, ganti ID:
   ```javascript
   const SPREADSHEET_ID = 'ID_DARI_LANGKAH_3';
   ```
5. Klik **Save** (Ctrl+S)
6. Di dropdown function, pilih **`testConnection`**
7. Klik **Jalankan** → izinkan akses jika diminta
8. Cek **Log eksekusi** → harus muncul:
   ```
   Test berhasil! Cek spreadsheet — 3 sheet baru: Cleaning, Service, Instalasi.
   ```

---

## LANGKAH 5 — Deploy Apps Script sebagai Web App

1. Klik **Terapkan → Deployment baru**
2. Klik ikon ⚙️ → pilih **Web App**
3. Isi form:
   - **Description**: HCS Checklist AC v1
   - **Execute as**: Me
   - **Who has access**: **Anyone** ← WAJIB
4. Klik **Deploy** → izinkan akses
5. **Copy URL** yang muncul:
   ```
   https://script.google.com/macros/s/AKfycb.../exec
   ```

---

## LANGKAH 6 — Hubungkan Aplikasi ke Google Sheets

1. Buka aplikasi di browser: `https://[USERNAME].github.io/hcs-checklist-ac`
2. Ketuk ikon ⚙️ di pojok kanan atas
3. Paste URL dari Langkah 5 ke kolom **URL Google Apps Script Web App**
4. Isi **Nama Teknisi Default** (opsional — nama teknisi yang pakai HP ini)
5. Ketuk **Test Koneksi** → tunggu konfirmasi ✅
6. Ketuk **Simpan Pengaturan**

> **Catatan:** Setup URL hanya perlu dilakukan sekali per HP. Pengaturan tersimpan di browser HP tersebut.

---

## CARA DISTRIBUSI KE TEKNISI

### Opsi A — Via URL (Rekomendasi)
Kirim URL aplikasi via WhatsApp group:
```
Halo tim! Silakan buka aplikasi checklist di:
https://[USERNAME].github.io/hcs-checklist-ac

Bookmark URL ini di browser HP masing-masing.
Setelah buka, masuk ke ⚙️ Pengaturan dan paste URL berikut:
[URL Apps Script]
```

### Opsi B — QR Code
Buat QR code dari URL aplikasi di `qr-code-generator.com` → print dan tempel di tempat briefing.

---

## CARA UPDATE APLIKASI

### Update kode (via GitHub web):
1. Buka repository di GitHub
2. Klik file yang ingin diedit (misal: `index.html`)
3. Klik ikon pensil (Edit)
4. Lakukan perubahan
5. Klik **Commit changes**
6. GitHub Pages otomatis update dalam 1–2 menit
7. Teknisi cukup **refresh browser** — langsung dapat versi terbaru

### Update Apps Script (jika ada perubahan di Code.gs):
1. Buka Apps Script → edit kode
2. **Terapkan → Kelola deployment → Edit → New version → Deploy**
3. URL tidak berubah

---

## STRUKTUR GOOGLE SHEETS SETELAH SETUP

### Sheet: Cleaning
| Kolom | Isi |
|---|---|
| ID | ID unik pekerjaan |
| Timestamp | Waktu data masuk |
| Tanggal & Jam | Tanggal & jam mulai |
| Status | selesai / draft |
| Tipe AC | Split, Cassette, dll |
| Teknisi | Nama teknisi |
| Customer | Nama & lokasi customer |
| Brand / PK / Freon | Data unit AC |
| Langkah selesai | Progress cleaning (misal: 10/12) |
| Before sesuai/tidak | Hasil parameter before |
| After sesuai/tidak | Hasil parameter after |

### Sheet: Service
Tambahan kolom: Keluhan customer, Tindakan dilakukan, Penyebab, Komponen bermasalah, Rekomendasi

### Sheet: Instalasi
Tambahan kolom: Helper, Jenis instalasi, Kendala, Rekomendasi maintenance

### Sheet: Parameter
Detail semua nilai aktual yang diisi teknisi per parameter per seksi.

### Sheet: Dashboard
Ringkasan otomatis: total pekerjaan, breakdown per jenis, teknisi aktif, alert parameter tidak sesuai.

---

## TIPS PENGGUNAAN

### Untuk Teknisi
- **Bookmark URL** di browser HP — tidak perlu download file
- Isi **Nama Teknisi Default** di ⚙️ supaya tidak perlu ketik nama setiap kali
- Kalau offline, data tersimpan otomatis — ketuk **Kirim Ulang** saat ada sinyal
- Jangan tutup browser sebelum muncul status ✅ atau ⚠️

### Untuk Katek / Admin
- Buka Google Sheets dari HP atau laptop kapan saja
- Filter kolom **"After tdk sesuai" > 0** untuk lihat pekerjaan yang perlu follow-up
- Sheet **Dashboard** update otomatis setiap data baru masuk
- Sort kolom **Tanggal** untuk lihat pekerjaan terbaru

---

## TROUBLESHOOTING

| Masalah | Solusi |
|---|---|
| Aplikasi tidak bisa dibuka | Cek apakah GitHub Pages sudah aktif di Settings |
| Data tidak masuk ke Sheets | Cek URL di ⚙️ pengaturan — harus ada `/exec` di ujung |
| Error "Access denied" | Pastikan "Who has access" = Anyone saat deploy |
| Data masuk tapi kosong | Jalankan `testConnection` ulang di Apps Script |
| Teknisi lupa URL | Kirim ulang URL via WhatsApp / QR code |

---

*Home Care Services — Sistem Checklist AC Digital*
*Versi 2.0 — Support: Cleaning, Service/Repair, Instalasi*
